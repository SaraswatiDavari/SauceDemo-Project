package SaraswatiSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;

public class SauceDemo {
	public static void main(String[] args) throws InterruptedException{
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Selenium\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
		//ChromeDriver driver1 = new ChromeDriver();
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		WebElement username =driver.findElement(By.id("user-name"));
		username.isDisplayed();
		username.isEnabled();
	     username.sendKeys("standard_user");
	     System.out.println("put username successfully");
	     
	     WebElement password=driver.findElement(By.id("password"));
	     password.isDisplayed();
	     password.isEnabled();
	     password.sendKeys("secret_sauce");
	     System.out.println("put password successfully");

	     WebElement login=driver.findElement(By.id("login-button"));
	     login.isDisplayed();
	     login.isEnabled();
	     login.click();
	     System.out.println("login successfully done");
	     
	     WebElement Add_to_cart=driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
	     Add_to_cart.click();
	     System.out.println("add cart item1 successfully");
	     
	     WebElement Add_to_cart2=driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt"));
	     Add_to_cart2.click();
	     System.out.println("add cart item2 successfully");
	     
	     JavascriptExecutor j = (JavascriptExecutor)driver;
	     j.executeScript("window.scrollBy(0,100)");
	     //j.executeScript("window.scrollBy(0,-500)");
	     
	     Thread.sleep(4000);
	     WebElement remove_from_cart=driver.findElement(By.id("remove-sauce-labs-backpack"));
	     remove_from_cart.click();
	     System.out.println("Remove cart item1 successfully");
	     
	     
	}
}
